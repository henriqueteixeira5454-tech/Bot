import ErrorEmbed from '../../../formatting/embeds/ErrorEmbed.js';
import {ActionRowBuilder, ButtonBuilder, ButtonStyle, MessageFlags} from 'discord.js';
import CompletingBadWordCommand from './CompletingBadWordCommand.js';
import BadWord from '../../../database/BadWord.js';

export default class ShowBadWordCommand extends CompletingBadWordCommand {
    async execute(interaction) {
        const badWord = /** @type {?BadWord} */
            await BadWord.getByID(interaction.options.getInteger('id', true), interaction.guildId);

        if (!badWord) {
            await interaction.reply(ErrorEmbed.message('There is no bad-word with this id.'));
            return;
        }

        await interaction.reply({
            flags: MessageFlags.Ephemeral,
            embeds: [badWord.embed()],
            components: [
                new ActionRowBuilder()
                    .addComponents(
                        // eslint-disable-next-line jsdoc/reject-any-type
                        /** @type {*} */
                        new ButtonBuilder()
                            .setLabel('Delete')
                            .setStyle(ButtonStyle.Danger)
                            .setCustomId(`bad-word:delete:${badWord.id}`),
                        // eslint-disable-next-line jsdoc/reject-any-type
                        /** @type {*} */
                        new ButtonBuilder()
                            .setLabel('Edit')
                            .setStyle(ButtonStyle.Secondary)
                            .setCustomId(`bad-word:edit:${badWord.id}`)
                    )
            ]
        });
    }

    getDescription() {
        return 'Show a single bad-word';
    }

    getName() {
        return 'show';
    }
}
